#!/bin/bash
# One-time setup on Raspberry Pi OS Bookworm (Pi 3A). Run:  bash install.sh
set -e
sudo apt update
sudo apt install -y python3-picamera2 python3-opencv python3-numpy python3-lgpio
# pigpio gives jitter-free servo pulses on any pin; lgpio is the fallback
if sudo apt install -y pigpio python3-pigpio; then
    sudo systemctl enable --now pigpiod
else
    echo "pigpio not available - will use lgpio (software PWM, a little servo jitter)"
fi
mkdir -p ~/tracker_logs
echo "Done. Test the camera with:  rpicam-hello -t 3000"
