#!/usr/bin/env python3
"""
Servo bench test / setup helper for the pan-tilt mount.

  python3 servo_test.py            interactive
  python3 servo_test.py --sweep    slow sweep of both axes

Commands (interactive):
  p 20        pan to +20 deg          t -15     tilt to -15 deg
  c           centre both (0, 0)      us pan 1450   send a raw pulse (microseconds)
  sweep       sweep both axes          q         quit

Use it to find, for each servo:
  center_us  - the pulse where the camera looks STRAIGHT DOWN
  us_per_deg - (pulse at +45 deg - pulse at -45 deg) / 90
  min/max_deg - how far it can go before hitting the frame or cables
and write them into config.json -> "servos".
"""
import argparse
import time

import tracker as T


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=T.DEFAULT_CONFIG_PATH)
    ap.add_argument("--sweep", action="store_true")
    args = ap.parse_args()
    cfg = T.load_config(args.config)
    sc = cfg["servos"]
    pt = T.PanTilt(sc)
    print(f"pan  = GPIO{sc['pan']['gpio']}  (physical pin 38)")
    print(f"tilt = GPIO{sc['tilt']['gpio']} (physical pin 40)")
    pt.move_to(0, 0)
    try:
        if args.sweep:
            for axis in ("pan", "tilt"):
                lo, hi = sc[axis]["min_deg"], sc[axis]["max_deg"]
                print(f"sweeping {axis} {lo} .. {hi}")
                for a in list(range(0, int(hi) + 1, 5)) + list(range(int(hi), int(lo) - 1, -5)) + \
                        list(range(int(lo), 1, 5)):
                    pt.move_to(a if axis == "pan" else 0, a if axis == "tilt" else 0)
                    time.sleep(0.05)
            return
        print(__doc__.split("Commands (interactive):")[1].split("Use it")[0])
        while True:
            try:
                cmd = input(f"[pan {pt.pan:+.1f}  tilt {pt.tilt:+.1f}] > ").strip().split()
            except EOFError:
                break
            if not cmd:
                continue
            try:
                if cmd[0] == "q":
                    break
                elif cmd[0] == "c":
                    pt.move_to(0, 0)
                elif cmd[0] == "p":
                    pt.move_to(float(cmd[1]), pt.tilt)
                elif cmd[0] == "t":
                    pt.move_to(pt.pan, float(cmd[1]))
                elif cmd[0] == "us":
                    axis, us = cmd[1], int(cmd[2])
                    if not 500 <= us <= 2500:
                        print("keep pulses between 500 and 2500 us")
                        continue
                    pt.backend.pulse(sc[axis]["gpio"], us)
                    print(f"{axis} pulse {us} us")
                elif cmd[0] == "sweep":
                    for a in list(range(-40, 41, 5)) + list(range(40, -41, -5)) + [0]:
                        pt.move_to(a, a)
                        time.sleep(0.05)
                else:
                    print("unknown command")
            except (IndexError, ValueError):
                print("bad command")
    finally:
        pt.move_to(0, 0)
        time.sleep(0.3)
        pt.release()


if __name__ == "__main__":
    main()
