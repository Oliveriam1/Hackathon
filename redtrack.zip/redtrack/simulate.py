#!/usr/bin/env python3
"""
Desktop simulator: renders what the gimbal camera would see from a drone and runs the real
tracker code against it. Lets you test search / lock / tracking logic on a PC, no Pi needed.

  python3 simulate.py                         target 45 m E, 40 m S of the drone
  python3 simulate.py --target 10 5 --preview
  python3 simulate.py --roll 90               camera mounted rotated 90 deg (like the test photo)
"""
import argparse
import math
import time

import cv2
import numpy as np

import tracker as T


def rot_x(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def rot_y(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def rot_z(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def make_ground_texture(size=1024, seed=1):
    """Concrete + camouflage net, coloured roughly as the NoIR camera sees it (washed out/pinkish)."""
    rng = np.random.default_rng(seed)
    tex = np.full((size, size, 3), (196, 190, 196), np.float32)          # concrete (BGR)
    noise = cv2.GaussianBlur(rng.normal(0, 1, (size, size)).astype(np.float32), (0, 0), 25)
    noise /= noise.std()
    camo_cols = [(128, 124, 120), (100, 104, 98), (160, 156, 158), (150, 140, 152)]  # last = IR-bright foliage
    for k, col in enumerate(camo_cols):
        n2 = cv2.GaussianBlur(rng.normal(0, 1, (size, size)).astype(np.float32), (0, 0), 12)
        n2 /= n2.std()
        m = (noise > 0.2) & (n2 > 0.3 + 0.25 * k)
        tex[m] = col
    tex += rng.normal(0, 4, tex.shape)
    return np.clip(tex, 0, 255).astype(np.uint8)


class SimWorld:
    def __init__(self, target_xy, altitude=20.0, roll_deg=0.0, drift=(0.3, -0.2), size=(1640, 1232),
                 hfov=62.2, vfov=48.8, target_bgr=(169, 154, 181), diameter=0.2):
        self.t_xy = np.array(target_xy, float)
        self.h = altitude
        self.roll = math.radians(roll_deg)
        self.drift = np.array(drift, float)
        self.width, self.height = size
        self.hfov, self.vfov = hfov, vfov
        self.fx = (self.width / 2) / math.tan(math.radians(hfov) / 2)
        self.fy = (self.height / 2) / math.tan(math.radians(vfov) / 2)
        self.tex = make_ground_texture()
        self.tex_res = 0.05                 # metres per texel
        self.target_bgr = np.array(target_bgr, np.float32)
        self.diam = diameter
        self.t0 = time.time()
        self.pt = None
        self.frames = 0
        self.max_frames = None
        self.on_done = None

    def drone_pos(self):
        t = time.time() - self.t0
        return np.array([*(self.drift * t), self.h])

    def R(self):
        pan, tilt = math.radians(self.pt.pan or 0), math.radians(self.pt.tilt or 0)
        return rot_y(pan) @ rot_x(tilt) @ rot_z(self.roll)

    def render(self):
        R, C = self.R(), self.drone_pos()
        w, h = self.width // 2, self.height // 2       # render ground at half res, upscale
        xs = (np.arange(w) * 2 + 1 - (self.width - 1) / 2) / self.fx
        ys = (np.arange(h) * 2 + 1 - (self.height - 1) / 2) / self.fy
        X, Y = np.meshgrid(xs, ys)
        d = np.stack([X, -Y, -np.ones_like(X)], -1) @ R.T
        dz = np.minimum(d[..., 2], -1e-3)
        t = C[2] / -dz
        gx, gy = C[0] + t * d[..., 0], C[1] + t * d[..., 1]
        u = (gx / self.tex_res).astype(np.int64) % self.tex.shape[1]
        v = (gy / self.tex_res).astype(np.int64) % self.tex.shape[0]
        img = self.tex[v, u]
        img[d[..., 2] > -0.05] = (230, 225, 230)                           # sky/horizon
        img = cv2.resize(img, (self.width, self.height), interpolation=cv2.INTER_LINEAR)

        # target disc, drawn with exact coverage (anti-aliased) so tiny far-away discs are right
        ang = np.linspace(0, 2 * np.pi, 64, endpoint=False)
        P = np.stack([self.t_xy[0] + self.diam / 2 * np.cos(ang),
                      self.t_xy[1] + self.diam / 2 * np.sin(ang), np.zeros_like(ang)], 1)
        v_cam = (P - C) @ R            # world -> camera
        if np.all(v_cam[:, 2] < 0):
            px = (self.width - 1) / 2 + self.fx * v_cam[:, 0] / -v_cam[:, 2]
            py = (self.height - 1) / 2 + self.fy * -v_cam[:, 1] / -v_cam[:, 2]
            x0, y0 = int(px.min()) - 2, int(py.min()) - 2
            x1, y1 = int(px.max()) + 3, int(py.max()) + 3
            if x1 > 0 and y1 > 0 and x0 < self.width and y0 < self.height and x1 - x0 < 2000:
                S = 8
                m = np.zeros(((y1 - y0) * S, (x1 - x0) * S), np.uint8)
                pts = np.stack([(px - x0) * S, (py - y0) * S], 1).astype(np.int32)
                cv2.fillPoly(m, [pts], 255)
                cov = cv2.resize(m, (x1 - x0, y1 - y0), interpolation=cv2.INTER_AREA)[..., None] / 255.0
                cx0, cy0 = max(0, x0), max(0, y0)
                cx1, cy1 = min(self.width, x1), min(self.height, y1)
                c = cov[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
                roi = img[cy0:cy1, cx0:cx1].astype(np.float32)
                img[cy0:cy1, cx0:cx1] = (roi * (1 - c) + self.target_bgr * c).astype(np.uint8)
        img = cv2.GaussianBlur(img, (3, 3), 0.7)                           # lens softness
        noise = np.random.normal(0, 2.5, img.shape)
        return np.clip(img + noise, 0, 255).astype(np.uint8)

    def true_error_deg(self):
        """Angle between the camera axis and the real target direction."""
        R, C = self.R(), self.drone_pos()
        v = np.array([*self.t_xy, 0]) - C
        axis = R @ np.array([0, 0, -1.0])
        return math.degrees(math.acos(np.clip(v @ axis / np.linalg.norm(v), -1, 1)))


class SimCamera:
    def __init__(self, world):
        self.world = world
        self.width, self.height = world.width, world.height
        self.hfov, self.vfov = world.hfov, world.vfov
        self.errors = []

    def read(self):
        w = self.world
        w.frames += 1
        if w.max_frames and w.frames >= w.max_frames and w.on_done:
            w.on_done()
        self.errors.append(w.true_error_deg())
        return w.render(), {"ColourGains": (1.5, 1.5)}

    def close(self):
        pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", nargs=2, type=float, default=[45, -40], help="metres east, north")
    ap.add_argument("--alt", type=float, default=20)
    ap.add_argument("--roll", type=float, default=90, help="camera mount rotation in degrees")
    ap.add_argument("--frames", type=int, default=150)
    ap.add_argument("--res", nargs=2, type=int, default=[1640, 1232], help="camera resolution")
    ap.add_argument("--preview", action="store_true")
    args = ap.parse_args()

    cfg = T.load_config(None)
    cfg["servos"]["backend"] = "dummy"
    cfg["servos"]["sec_per_deg"] = 0.0
    cfg["servos"]["settle_s"] = 0.0
    cfg["logging"]["dir"] = "sim_logs"
    cfg["target"]["altitude_m"] = args.alt

    pt = T.PanTilt(cfg["servos"])
    pt.move_to(0, 0, wait=False)

    # 1) calibrate the axes exactly like on the real drone (circle placed near the centre)
    import os
    # (like holding a big printed circle in view: 1 m disc, 1.5 m / 1 m off centre)
    w = SimWorld((1.5, 1.0), altitude=args.alt, roll_deg=args.roll, drift=(0, 0), diameter=1.0,
                 size=tuple(args.res))
    w.pt = pt

    class A:
        config = "sim_config.json"
        cal_step = 6.0
        cal_size_prior = True
    if os.path.exists(A.config):
        os.remove(A.config)
    T.calibrate_axes(A, T.deep_merge(cfg, {"target": {"diameter_m": 1.0}}), cam=SimCamera(w), pt=pt)
    cfg = T.deep_merge(cfg, T.load_config(A.config))
    cfg["servos"].update(backend="dummy", sec_per_deg=0.0, settle_s=0.0)
    cfg["logging"]["dir"] = "sim_logs"
    cfg["target"]["altitude_m"] = args.alt
    pt.move_to(0, 0, wait=False)

    world = SimWorld(args.target, altitude=args.alt, roll_deg=args.roll, size=tuple(args.res))
    world.pt = pt
    world.max_frames = args.frames
    cam = SimCamera(world)
    tr = T.Tracker(cfg, cam, pt, preview=args.preview, snapshots=True)
    world.on_done = tr.stop
    t = time.time()
    tr.run()
    e = cam.errors
    lock_idx = next((i for i, v in enumerate(e) if v < 1.0), None)
    print(f"\nframes {len(e)} in {time.time() - t:.1f}s   final pointing error {e[-1]:.2f} deg   "
          f"mean error over last 30 frames {np.mean(e[-30:]):.2f} deg   first <1 deg at frame {lock_idx}")


if __name__ == "__main__":
    main()
