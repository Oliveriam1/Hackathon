#!/usr/bin/env python3
"""
Red-circle finder and pan/tilt tracker
Raspberry Pi 3A + Pi NoIR camera + 2x MG996R servos (pan on pin 38, tilt on pin 40)

Modes
  python3 tracker.py                      run the tracker (search -> lock -> track)
  python3 tracker.py --preview            same, with a live window (needs a display / VNC)
  python3 tracker.py --learn              learn the target colour from the middle of the view
  python3 tracker.py --calibrate-axes     learn which servo moves the image which way
  python3 tracker.py --image a.jpg        detection only, on saved image(s)  (works on a PC too)

All tuning lives in config.json next to this file.
"""
import argparse
import copy
import glob
import json
import math
import os
import signal
import time

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CONFIG_PATH = os.path.join(HERE, "config.json")

# --------------------------------------------------------------------------------------
# Default configuration (config.json overrides any of these)
# --------------------------------------------------------------------------------------
DEFAULTS = {
    "camera": {
        "resolution": "auto",        # "auto" = largest *binned full-field-of-view* mode, or [w, h]
        "hfov_deg": None,            # None = look up from the detected sensor
        "vfov_deg": None,
        "tuning": "auto",            # "auto" = load the NoIR tuning file for the sensor
        "colour_gains": None,        # [red, blue] to lock white balance (written by --learn)
        "exposure_us": None,         # None = auto exposure. Short (<2000) reduces motion blur
        "analogue_gain": None,
        "buffer_count": 3,
    },
    "target": {
        "diameter_m": 0.20,
        "altitude_m": 20.0,
        "use_size_prior": True,      # reject blobs far too big/small for a 20 cm disc at this height
        "size_min_factor": 0.2,      # accepted area = expected * [min_factor, max_factor]
        "size_max_factor": 5.0,
        "min_area_px": 2,
        "max_area_px": 60000,
    },
    "colour": {
        # Target colour model in normalised chromaticity (r = R/(R+G+B), g = G/(R+G+B)).
        # Defaults come from the test photo (NoIR, indoors). Run --learn outdoors!
        "mean": [0.357, 0.306],
        "cov": [[1.6e-05, -0.6e-05], [-0.6e-05, 1.6e-05]],
        "max_dist": 3.0,             # Mahalanobis distance; bigger = looser
        "min_sum": 60,               # ignore dark pixels (R+G+B)
        "max_sum": 750,              # ignore blown-out pixels
        "min_red_excess": 0.015,     # require r - g >= this (keeps grey/white out)
    },
    "detect": {
        "blur": 3,                   # 3x3 smoothing before colour test (kills sensor noise), 0 = off
        "min_density": 0.35,         # small blobs: pixels / bounding box
        "max_mean_dist_frac": 0.8,   # blob mean colour distance must be < this * max_dist
        "tiny_area_px": 10,          # blobs smaller than this must have a cleaner colour:
        "tiny_max_mean_dist_frac": 0.55,
        "ring_max_frac": 0.25,       # isolation: max share of the surrounding ring that is
                                     # "nearly target coloured" (rejects bits of big pink areas)
    },
    "shape": {
        "min_solidity": 0.75,        # blob area / convex hull area (noise clusters are ragged)
        "check_min_area_px": 40,     # only blobs at least this big get a roundness check
        "min_fill": 0.65,            # blob area / fitted ellipse area
        "min_aspect": 0.18,          # minor/major axis (a disc seen at 70 deg is ~0.33)
    },
    "servos": {
        "backend": "auto",           # auto | pigpio | lgpio | dummy
        "pan":  {"gpio": 20, "center_us": 1500, "us_per_deg": 11.1, "min_deg": -90, "max_deg": 90},
        "tilt": {"gpio": 21, "center_us": 1500, "us_per_deg": 11.1, "min_deg": -80, "max_deg": 80},
        "sec_per_deg": 0.0035,       # MG996R ~0.17 s / 60 deg at 4.8 V, plus margin
        "settle_s": 0.06,
    },
    "control": {
        "keyhole_deg": 1.0,          # target this close to straight down: don't swing pan
        "gain": 0.7,
        "deadband_deg": 0.25,
        "max_step_deg": 30.0,
        "confirm_frames": 3,         # detections needed before locking on
        "confirm_radius_deg": 2.5,
        "lock_max_core_dist": 1.6,   # to LOCK, the best 25 % of blob pixels must be this close
                                     # to the learned colour (the real circle is ~1, look-alikes 2+)
        "lost_frames": 8,            # frames without target before searching again
        "roi_deg": 5.0,              # half-size of the tracking window (the gate)
    },
    "gimbal": {
        # Pan turns the whole head around the vertical axis, tilt swings the camera away from
        # straight down (tilt 0 = straight down). These four are found by --calibrate-axes.
        "pan_sign": 1,
        "tilt_sign": 1,
        "image_roll_deg": 0.0,       # how the picture is rotated relative to the tilt direction
        "mirror": 1,
    },
    "search": {
        "max_off_nadir_deg": 80.0,   # 60 m sideways at 20 m height = 71.6 deg
        "step_deg": None,            # None = 60 % of the smaller field of view
        "dwell_frames": 2,
    },
    "logging": {
        "dir": "~/tracker_logs",
        "save_every_s": 5.0,
        "max_images": 400,
        "print_every_s": 0.5,
        "save_raw": False,           # also save untouched full-size frames (for re-tuning on a PC)
    },
}

# Full-sensor field of view (degrees) for known Pi camera sensors
SENSOR_FOV = {
    "ov5647": (53.5, 41.4),          # Camera v1 (5 MP)
    "imx219": (62.2, 48.8),          # Camera v2 (8 MP)
    "imx708": (66.0, 41.0),          # Camera v3 (12 MP) standard lens
    "imx708_wide": (102.0, 67.0),    # Camera v3 wide
}


def deep_merge(base, over):
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path):
    user = {}
    if path and os.path.exists(path):
        with open(path) as f:
            user = json.load(f)
    return deep_merge(DEFAULTS, user)


def save_config_section(path, section, values):
    """Update one section of config.json without touching the rest."""
    data = {}
    if os.path.exists(path):
        with open(path) as f:
            data = json.load(f)
    data.setdefault(section, {}).update(values)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    print(f"[config] saved '{section}' to {path}")


def log(msg):
    print(time.strftime("%H:%M:%S ") + msg, flush=True)


# --------------------------------------------------------------------------------------
# Colour model -> 18-bit lookup table (6 bits per channel) giving a "distance" per colour
# --------------------------------------------------------------------------------------
DIST_SCALE = 25.0   # LUT value = distance * DIST_SCALE, 255 = never matches


class ColourModel:
    def __init__(self, cc):
        self.cc = cc
        self.lut = self._build_lut(cc)
        self.threshold = int(min(254, cc["max_dist"] * DIST_SCALE))

    @staticmethod
    def _build_lut(cc):
        v = np.arange(64, dtype=np.float32) * 4 + 2
        B, G, R = np.meshgrid(v, v, v, indexing="ij")   # index = b<<12 | g<<6 | r
        S = R + G + B
        rn, gn = R / S, G / S
        mean = np.array(cc["mean"], np.float32)
        icov = np.linalg.inv(np.array(cc["cov"], np.float64)).astype(np.float32)
        d0, d1 = rn - mean[0], gn - mean[1]
        m2 = icov[0, 0] * d0 * d0 + 2 * icov[0, 1] * d0 * d1 + icov[1, 1] * d1 * d1
        q = np.clip(np.sqrt(np.maximum(m2, 0)) * DIST_SCALE, 0, 254)
        bad = (S < cc["min_sum"]) | (S > cc["max_sum"]) | ((rn - gn) < cc["min_red_excess"])
        q[bad] = 255
        return q.astype(np.uint8).ravel()

    def distance_image(self, bgr):
        """uint8 image: colour distance * DIST_SCALE (255 = not a target colour)."""
        f = bgr >> 2
        idx = f[..., 0].astype(np.uint32)
        idx <<= 6
        idx |= f[..., 1]
        idx <<= 6
        idx |= f[..., 2]
        return self.lut[idx]

    @staticmethod
    def learn(pixels_bgr, min_sd=0.004):
        """Build a colour model from target pixels (N x 3, BGR)."""
        p = pixels_bgr.reshape(-1, 3).astype(np.float64)
        S = p.sum(1)
        keep = S > 30
        p, S = p[keep], S[keep]
        if len(p) < 20:
            raise ValueError("not enough target pixels to learn from")
        rn, gn = p[:, 2] / S, p[:, 1] / S
        x = np.stack([rn, gn], 1)
        # drop the 10 % most unusual pixels (edges, glare) then refit
        med = np.median(x, 0)
        d = np.linalg.norm(x - med, axis=1)
        x = x[d <= np.percentile(d, 90)]
        mean = x.mean(0)
        cov = np.cov(x.T)
        # never let the model become razor thin; outdoor light will vary
        w, V = np.linalg.eigh(cov)
        w = np.maximum(w, min_sd ** 2)
        cov = V @ np.diag(w) @ V.T
        cov = (cov + cov.T) / 2
        lo, hi = np.percentile(S, [3, 97])
        excess = float(mean[0] - mean[1])
        return {
            "mean": [round(float(mean[0]), 5), round(float(mean[1]), 5)],
            "cov": [[float("%.3g" % cov[0, 0]), float("%.3g" % cov[0, 1])],
                    [float("%.3g" % cov[1, 0]), float("%.3g" % cov[1, 1])]],
            "min_sum": int(max(30, lo * 0.4)),
            "max_sum": int(min(765, hi * 1.6 + 20)),
            "min_red_excess": round(max(0.0, excess * 0.35), 4),
        }


# --------------------------------------------------------------------------------------
# Detector
# --------------------------------------------------------------------------------------
class Detector:
    def __init__(self, cfg, width, height, hfov_deg, vfov_deg):
        self.cfg = cfg
        self.colour = ColourModel(cfg["colour"])
        self.set_geometry(width, height, hfov_deg, vfov_deg)

    def set_geometry(self, width, height, hfov_deg, vfov_deg):
        self.w, self.h = width, height
        self.cx, self.cy = (width - 1) / 2.0, (height - 1) / 2.0
        self.fx = (width / 2.0) / math.tan(math.radians(hfov_deg) / 2)
        self.fy = (height / 2.0) / math.tan(math.radians(vfov_deg) / 2)
        self.hfov, self.vfov = hfov_deg, vfov_deg

    # pixel <-> angle (degrees from the optical axis)
    def pix_to_deg(self, x, y):
        return (math.degrees(math.atan((x - self.cx) / self.fx)),
                math.degrees(math.atan((y - self.cy) / self.fy)))

    def deg_to_pix(self, ax, ay):
        return (self.cx + self.fx * math.tan(math.radians(ax)),
                self.cy + self.fy * math.tan(math.radians(ay)))

    def expected_area(self, pan_deg, tilt_deg):
        t = self.cfg["target"]
        cos_t = max(0.05, math.cos(math.radians(tilt_deg)))   # tilt = angle from straight down
        major = self.fx * t["diameter_m"] * cos_t / max(0.5, t["altitude_m"])
        return math.pi / 4 * major * major * cos_t

    def detect(self, bgr, roi=None, pointing=(0.0, 0.0), prefer_deg=None, use_size_prior=None):
        """Returns candidates sorted best-first. roi = (x0, y0, x1, y1)."""
        tc, sc = self.cfg["target"], self.cfg["shape"]
        if use_size_prior is None:
            use_size_prior = tc["use_size_prior"]
        x0 = y0 = 0
        img = bgr
        if roi is not None:
            x0, y0, x1, y1 = roi
            img = bgr[y0:y1, x0:x1]
        k = self.cfg["detect"]["blur"]
        if k and k > 1:
            img = cv2.blur(img, (k, k))
        dist = self.colour.distance_image(img)
        mask = (dist <= self.colour.threshold).astype(np.uint8)
        n, labels, stats, cents = cv2.connectedComponentsWithStats(mask, connectivity=8)
        if n <= 1:
            return []
        areas = stats[1:, cv2.CC_STAT_AREA]
        amin, amax = tc["min_area_px"], tc["max_area_px"]
        if use_size_prior:
            exp_a = self.expected_area(*pointing)
            amin = max(amin, exp_a * tc["size_min_factor"])
            amax = min(amax, max(exp_a * tc["size_max_factor"], amin + 4))
        else:
            exp_a = None
        dc = self.cfg["detect"]
        dens = areas / (stats[1:, cv2.CC_STAT_WIDTH] * stats[1:, cv2.CC_STAT_HEIGHT]).astype(np.float32)
        # mean colour distance of every blob in one pass
        fg = mask.view(bool)
        dsum = np.bincount(labels[fg], weights=dist[fg].astype(np.float32), minlength=n)[1:]
        mean_ds = dsum / np.maximum(areas, 1) / DIST_SCALE
        md = self.cfg["colour"]["max_dist"]
        dlim = np.where(areas < dc["tiny_area_px"], dc["tiny_max_mean_dist_frac"] * md,
                        dc["max_mean_dist_frac"] * md)
        good = ((areas >= amin) & (areas <= amax) & (dens >= dc["min_density"]) & (mean_ds <= dlim))
        ok = np.nonzero(good)[0] + 1
        if len(ok) == 0:
            return []
        pre = np.sqrt(areas[ok - 1]) * (1.3 - mean_ds[ok - 1] / self.cfg["colour"]["max_dist"])
        ok = ok[np.argsort(-pre)][:40]

        cands = []
        for i in ok:
            x, y, w, h, area = stats[i]
            sub_lab = labels[y:y + h, x:x + w] == i
            mean_d = float(mean_ds[i - 1])
            core_d = float(np.percentile(dist[y:y + h, x:x + w][sub_lab], 25)) / DIST_SCALE
            # isolation test: look at a ring around the blob
            pad = max(3, int(max(w, h) * 0.75))
            rx0, ry0 = max(0, x - pad), max(0, y - pad)
            rx1, ry1 = min(dist.shape[1], x + w + pad), min(dist.shape[0], y + h + pad)
            ring_d = dist[ry0:ry1, rx0:rx1]
            ring_m = labels[ry0:ry1, rx0:rx1] != i
            near = (ring_d[ring_m] <= min(254, 2 * self.colour.threshold)).mean() if ring_m.any() else 0
            if near > dc["ring_max_frac"]:
                continue
            fill, aspect = 1.0, min(w, h) / max(w, h)
            if area >= sc["check_min_area_px"]:
                cnts, _ = cv2.findContours(sub_lab.astype(np.uint8), cv2.RETR_EXTERNAL,
                                           cv2.CHAIN_APPROX_NONE)
                c = max(cnts, key=cv2.contourArea)
                hull_a = cv2.contourArea(cv2.convexHull(c))
                if hull_a > 0 and area / hull_a < sc["min_solidity"]:
                    continue
                if len(c) >= 5:
                    (_, _), (ea, eb), _ = cv2.fitEllipse(c)
                    if ea > 0 and eb > 0:
                        fill = area / (math.pi / 4 * ea * eb)
                        aspect = min(ea, eb) / max(ea, eb)
                if fill < sc["min_fill"] or aspect < sc["min_aspect"]:
                    continue
            px, py = cents[i][0] + x0, cents[i][1] + y0
            ax, ay = self.pix_to_deg(px, py)
            score = math.sqrt(area) * max(0.05, 1.3 - core_d / self.cfg["colour"]["max_dist"])
            score *= min(1.0, fill)
            if exp_a:
                score *= math.exp(-0.5 * (math.log(area / exp_a) / 1.0) ** 2) * 0.7 + 0.3
            if prefer_deg is not None:
                dd = math.hypot(ax - prefer_deg[0], ay - prefer_deg[1])
                score *= math.exp(-(dd / max(1.0, self.cfg["control"]["roi_deg"])) ** 2) * 0.8 + 0.2
            cands.append({"x": px, "y": py, "ax": ax, "ay": ay, "area": int(area),
                          "bbox": (int(x + x0), int(y + y0), int(w), int(h)),
                          "fill": round(fill, 2), "aspect": round(aspect, 2),
                          "cdist": round(mean_d, 2), "core": round(core_d, 2), "score": score})
        cands.sort(key=lambda c: -c["score"])
        return cands


# --------------------------------------------------------------------------------------
# Servos
# --------------------------------------------------------------------------------------
class _PigpioBackend:
    name = "pigpio"

    def __init__(self):
        import pigpio
        self.pi = pigpio.pi()
        if not self.pi.connected:
            raise RuntimeError("pigpiod not running (sudo systemctl enable --now pigpiod)")

    def pulse(self, gpio, us):
        self.pi.set_servo_pulsewidth(gpio, int(us))

    def close(self):
        self.pi.stop()


class _LgpioBackend:
    name = "lgpio (software PWM - expect some jitter)"

    def __init__(self):
        import lgpio
        self.lg = lgpio
        self.h = lgpio.gpiochip_open(0)
        self.claimed = set()

    def pulse(self, gpio, us):
        if gpio not in self.claimed:
            self.lg.gpio_claim_output(self.h, gpio)
            self.claimed.add(gpio)
        self.lg.tx_servo(self.h, gpio, int(us), 50)

    def close(self):
        self.lg.gpiochip_close(self.h)


class _DummyBackend:
    name = "dummy (no servos)"

    def pulse(self, gpio, us):
        pass

    def close(self):
        pass


def make_servo_backend(name):
    order = ["pigpio", "lgpio"] if name == "auto" else [name]
    for n in order:
        try:
            return {"pigpio": _PigpioBackend, "lgpio": _LgpioBackend,
                    "dummy": _DummyBackend}[n]()
        except Exception as e:  # noqa
            log(f"[servo] {n} unavailable: {e}")
    log("[servo] WARNING: no servo driver, running without servos")
    return _DummyBackend()


class PanTilt:
    def __init__(self, sc, backend=None):
        self.sc = sc
        self.backend = backend or make_servo_backend(sc["backend"])
        log(f"[servo] driver: {self.backend.name}")
        self.pan = self.tilt = None

    def _us(self, axis, deg):
        a = self.sc[axis]
        return a["center_us"] + deg * a["us_per_deg"]

    def clamp(self, pan, tilt):
        p, t = self.sc["pan"], self.sc["tilt"]
        return (min(p["max_deg"], max(p["min_deg"], pan)),
                min(t["max_deg"], max(t["min_deg"], tilt)))

    def move_to(self, pan, tilt, wait=True):
        pan, tilt = self.clamp(pan, tilt)
        if self.pan is None:
            travel = 90.0
        else:
            travel = max(abs(pan - self.pan), abs(tilt - self.tilt))
        self.backend.pulse(self.sc["pan"]["gpio"], self._us("pan", pan))
        self.backend.pulse(self.sc["tilt"]["gpio"], self._us("tilt", tilt))
        self.pan, self.tilt = pan, tilt
        if wait and travel > 0:
            time.sleep(self.sc["settle_s"] + travel * self.sc["sec_per_deg"])
        return pan, tilt

    def release(self):
        for axis in ("pan", "tilt"):
            try:
                self.backend.pulse(self.sc[axis]["gpio"], 0)
            except Exception:
                pass
        self.backend.close()



# --------------------------------------------------------------------------------------
# Gimbal geometry: pan (azimuth, turns the whole head) + tilt (angle from straight down)
# --------------------------------------------------------------------------------------
def _rz(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def _ry(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, 0.0, s], [0.0, 1.0, 0.0], [-s, 0.0, c]])


class Gimbal:
    """
    World frame: Z up, camera at the origin. Pan rotates about Z, tilt rotates the camera away
    from straight down. A pixel offset (ax, ay in degrees) plus the servo angles gives an exact
    3D direction to the target; from that direction we solve the servo angles that centre it.
    This works everywhere, including straight down where pan only spins the picture.
    """

    def __init__(self, cfg, params=None):
        g = dict(cfg["gimbal"], **(params or {}))
        self.ps, self.ts = float(g["pan_sign"]), float(g["tilt_sign"])
        self.B = _rz(math.radians(g["image_roll_deg"])) @ np.diag([1.0, float(g["mirror"]), 1.0])
        sc = cfg["servos"]
        self.plim = (sc["pan"]["min_deg"], sc["pan"]["max_deg"])
        self.tlim = (sc["tilt"]["min_deg"], sc["tilt"]["max_deg"])
        self.keyhole = cfg["control"].get("keyhole_deg", 1.0)

    def R(self, pan, tilt):
        return _rz(math.radians(self.ps * pan)) @ _ry(math.radians(self.ts * tilt))

    def axis(self, pan, tilt):
        return self.R(pan, tilt) @ np.array([0.0, 0.0, -1.0])

    def world_dir(self, pan, tilt, ax, ay):
        r = np.array([math.tan(math.radians(ax)), -math.tan(math.radians(ay)), -1.0])
        w = self.R(pan, tilt) @ (self.B @ r)
        return w / np.linalg.norm(w)

    def project(self, w, pan, tilt):
        """World direction -> (ax, ay) image angles at this pose, None if behind the camera."""
        c = self.B.T @ (self.R(pan, tilt).T @ w)
        if c[2] > -1e-3:
            return None
        return (math.degrees(math.atan(c[0] / -c[2])), math.degrees(math.atan(c[1] / c[2])))

    @staticmethod
    def dir_from_polar(theta_deg, az_deg):
        t, a = math.radians(theta_deg), math.radians(az_deg)
        return np.array([math.sin(t) * math.cos(a), math.sin(t) * math.sin(a), -math.cos(t)])

    def angles_for(self, w, near):
        """Servo angles (pan, tilt) that point the camera along w, choosing the solution that
        is reachable and needs the least movement from `near`."""
        w = w / np.linalg.norm(w)
        theta = math.degrees(math.acos(max(-1.0, min(1.0, -w[2]))))
        if theta < self.keyhole:
            # almost straight down: keep pan, just tilt within the current pan plane
            v = _rz(math.radians(self.ps * near[0])).T @ w
            th = math.degrees(math.atan2(-v[0], -v[2]))
            return near[0], max(self.tlim[0], min(self.tlim[1], th / self.ts))
        phi = math.degrees(math.atan2(-w[1], -w[0]))
        best = None
        for ph, th in ((phi, theta), (phi + 180.0, -theta)):
            for k in (-360.0, 0.0, 360.0):
                pan, tilt = (ph + k) / self.ps, th / self.ts
                cp = max(self.plim[0], min(self.plim[1], pan))
                ct = max(self.tlim[0], min(self.tlim[1], tilt))
                miss = math.degrees(math.acos(max(-1.0, min(1.0, float(self.axis(cp, ct) @ w)))))
                move = max(abs(cp - near[0]), abs(ct - near[1]))
                key = (round(miss, 1), move)
                if best is None or key < best[0]:
                    best = (key, (cp, ct))
        return best[1]


def fit_gimbal(cfg, poses, obs):
    """Find pan/tilt signs, mirror, image roll (and whether the servos are swapped) that make
    all observations of one fixed target agree on a single world direction."""
    def rms_for(params, swap):
        g = Gimbal(cfg, params)
        ws = []
        for (p, t), (ax, ay) in zip(poses, obs):
            if swap:
                p, t = t, p
            ws.append(g.world_dir(p, t, ax, ay))
        ws = np.array(ws)
        m = ws.mean(0)
        m /= np.linalg.norm(m)
        ang = np.degrees(np.arccos(np.clip(ws @ m, -1, 1)))
        return float(np.sqrt((ang ** 2).mean()))

    best = None
    for swap in (False, True):
        for ps in (1, -1):
            for ts in (1, -1):
                for mir in (1, -1):
                    for roll in range(0, 360, 3):
                        prm = {"pan_sign": ps, "tilt_sign": ts, "mirror": mir, "image_roll_deg": roll}
                        e = rms_for(prm, swap)
                        if best is None or e < best[0]:
                            best = (e, prm, swap)
    e, prm, swap = best
    for roll in np.arange(prm["image_roll_deg"] - 3, prm["image_roll_deg"] + 3.01, 0.25):
        p2 = dict(prm, image_roll_deg=float(roll) % 360)
        e2 = rms_for(p2, swap)
        if e2 < e:
            e, prm = e2, p2
    prm["image_roll_deg"] = round(prm["image_roll_deg"], 2)
    return prm, swap, e

# --------------------------------------------------------------------------------------
# Camera (Picamera2 / libcamera, Raspberry Pi OS Bookworm)
# --------------------------------------------------------------------------------------
class PiCamera:
    def __init__(self, cc):
        from picamera2 import Picamera2
        info = Picamera2.global_camera_info()
        if not info:
            raise RuntimeError("no camera found - check the ribbon cable, then run 'rpicam-hello'")
        model = info[0].get("Model", "unknown").lower()
        self.model = model
        tuning = None
        if cc["tuning"] == "auto":
            if "noir" not in model and model in ("imx219", "ov5647"):
                try:
                    tuning = Picamera2.load_tuning_file(f"{model}_noir.json")
                except Exception as e:  # noqa
                    log(f"[camera] could not load NoIR tuning: {e}")
        elif cc["tuning"]:
            tuning = Picamera2.load_tuning_file(cc["tuning"])
        self.cam = Picamera2(tuning=tuning) if tuning else Picamera2()

        full_w, full_h = self.cam.camera_properties["PixelArraySize"]
        mode = self._pick_mode(cc["resolution"], full_w, full_h)
        size = tuple(mode["size"]) if isinstance(cc["resolution"], str) else tuple(cc["resolution"])
        size = (size[0] - size[0] % 2, size[1] - size[1] % 2)
        kwargs = dict(main={"size": size, "format": "RGB888"}, buffer_count=cc["buffer_count"])
        try:
            conf = self.cam.create_video_configuration(
                sensor={"output_size": mode["size"], "bit_depth": mode["bit_depth"]}, **kwargs)
        except TypeError:
            conf = self.cam.create_video_configuration(raw={"size": mode["size"]}, **kwargs)
        self.cam.configure(conf)
        self.width, self.height = self.cam.camera_configuration()["main"]["size"]

        crop_w = mode.get("crop_limits", (0, 0, full_w, full_h))[2] / full_w
        crop_h = mode.get("crop_limits", (0, 0, full_w, full_h))[3] / full_h
        base = "imx708_wide" if ("imx708" in model and "wide" in model) else model.split("_")[0]
        hf, vf = SENSOR_FOV.get(base, (None, None))
        if cc["hfov_deg"]:
            hf, vf = cc["hfov_deg"], cc["vfov_deg"] or cc["hfov_deg"] * self.height / self.width
        elif hf is None:
            log(f"[camera] unknown sensor '{model}', assuming 62x49 deg - set hfov_deg in config")
            hf, vf = 62.2, 48.8
        else:
            hf = 2 * math.degrees(math.atan(math.tan(math.radians(hf / 2)) * crop_w))
            vf = 2 * math.degrees(math.atan(math.tan(math.radians(vf / 2)) * crop_h))
        self.hfov, self.vfov = hf, vf

        controls = {}
        if cc["colour_gains"]:
            controls.update(AwbEnable=False, ColourGains=tuple(cc["colour_gains"]))
        if cc["exposure_us"]:
            controls.update(AeEnable=False, ExposureTime=int(cc["exposure_us"]))
        if cc["analogue_gain"]:
            controls.update(AnalogueGain=float(cc["analogue_gain"]))
        self.cam.start()
        if controls:
            self.cam.set_controls(controls)
        time.sleep(1.0)
        log(f"[camera] {model}  {self.width}x{self.height}  FOV {hf:.1f} x {vf:.1f} deg")

    def _pick_mode(self, want, full_w, full_h):
        modes = self.cam.sensor_modes
        def full_fov(m):
            cl = m.get("crop_limits")
            return cl is None or (cl[2] >= full_w * 0.98 and cl[3] >= full_h * 0.98)
        cands = [m for m in modes if full_fov(m)] or modes
        if isinstance(want, str):   # auto: largest binned full-FoV mode below the full res
            binned = [m for m in cands if m["size"][0] < full_w * 0.9]
            pool = binned or cands
            return max(pool, key=lambda m: m["size"][0])
        # smallest full-FoV mode at least as big as requested
        big = [m for m in cands if m["size"][0] >= want[0]]
        return min(big, key=lambda m: m["size"][0]) if big else max(cands, key=lambda m: m["size"][0])

    flush_ok = True

    def read(self):
        req = None
        if self.flush_ok:
            try:
                req = self.cam.capture_request(flush=True)   # frame exposed after this call
            except TypeError:
                self.flush_ok = False
                log("[camera] old picamera2 without flush=True - dropping a frame instead")
        if req is None:
            self.cam.capture_request().release()             # drop a possibly stale frame
            req = self.cam.capture_request()
        try:
            arr = req.make_array("main")
            meta = req.get_metadata()
        finally:
            req.release()
        return arr, meta

    def close(self):
        try:
            self.cam.stop()
            self.cam.close()
        except Exception:
            pass


# --------------------------------------------------------------------------------------
# Snapshot / preview drawing
# --------------------------------------------------------------------------------------
def annotate(frame, det, cands, state, pan, tilt, roi=None, width=820):
    s = width / frame.shape[1]
    out = cv2.resize(frame, (width, int(frame.shape[0] * s)), interpolation=cv2.INTER_AREA)
    cx, cy = int(det.cx * s), int(det.cy * s)
    cv2.drawMarker(out, (cx, cy), (0, 255, 0), cv2.MARKER_CROSS, 24, 1)
    if roi is not None:
        cv2.rectangle(out, (int(roi[0] * s), int(roi[1] * s)), (int(roi[2] * s), int(roi[3] * s)),
                      (255, 200, 0), 1)
    for k, c in enumerate(cands[:5]):
        col = (0, 255, 255) if k == 0 else (0, 128, 255)
        cv2.circle(out, (int(c["x"] * s), int(c["y"] * s)), max(8, int(math.sqrt(c["area"]) * s)), col, 2)
    if cands:
        c = cands[0]
        r = 40
        x, y = int(c["x"]), int(c["y"])
        crop = frame[max(0, y - r):y + r, max(0, x - r):x + r]
        if crop.size:
            crop = cv2.resize(crop, (160, 160), interpolation=cv2.INTER_NEAREST)
            out[0:160, out.shape[1] - 160:] = crop
            cv2.rectangle(out, (out.shape[1] - 160, 0), (out.shape[1] - 1, 159), (0, 255, 255), 1)
    txt = f"{state}  pan {pan:+.1f}  tilt {tilt:+.1f}"
    if cands:
        c = cands[0]
        txt += f"  err {c['ax']:+.1f},{c['ay']:+.1f}  area {c['area']}  d {c['cdist']}"
    cv2.putText(out, txt, (8, out.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 3)
    cv2.putText(out, txt, (8, out.shape[0] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    return out


class SnapshotLogger:
    def __init__(self, lc):
        self.dir = os.path.expanduser(lc["dir"])
        os.makedirs(self.dir, exist_ok=True)
        self.every = lc["save_every_s"]
        self.save_raw = lc.get("save_raw", False)
        self.max = lc["max_images"]
        self.last = 0.0
        self.count = 0

    def due(self, force=False):
        if self.every <= 0 or self.count >= self.max:
            return False
        return force or time.time() - self.last >= self.every

    def maybe_save(self, img, tag, force=False, raw=None):
        now = time.time()
        if self.due(force):
            path = os.path.join(self.dir, time.strftime("%Y%m%d_%H%M%S") + f"_{self.count:04d}_{tag}.jpg")
            cv2.imwrite(path, img, [cv2.IMWRITE_JPEG_QUALITY, 85])
            if self.save_raw and raw is not None:
                cv2.imwrite(path[:-4] + "_raw.png", raw)
            self.last = now
            self.count += 1


# --------------------------------------------------------------------------------------
# Tracker state machine
# --------------------------------------------------------------------------------------
class Tracker:
    SEARCH, TRACK = "SEARCH", "TRACK"

    def __init__(self, cfg, camera, pantilt, preview=False, snapshots=True):
        self.cfg = cfg
        self.cam = camera
        self.pt = pantilt
        self.det = Detector(cfg, camera.width, camera.height, camera.hfov, camera.vfov)
        self.g = Gimbal(cfg)
        self.preview = preview
        self.snap = SnapshotLogger(cfg["logging"]) if snapshots else None
        self.running = True
        self.state = self.SEARCH
        self.last_print = 0.0
        self.last_lock = (0.0, 0.0)
        self.frames = 0
        self.t0 = time.time()

    # -- search pattern -----------------------------------------------------------------
    def search_points(self, around=(0.0, 0.0)):
        """Rings of look directions around straight down, nearest to `around` first."""
        sc = self.cfg["search"]
        step = sc["step_deg"] or 0.6 * min(self.det.hfov, self.det.vfov)
        maxoff = sc["max_off_nadir_deg"]
        dirs = [self.g.dir_from_polar(0, 0)]
        nr = max(1, math.ceil(maxoff / step))
        for k in range(1, nr + 1):
            th = maxoff * k / nr
            n = max(3, math.ceil(360 * math.sin(math.radians(th)) / step))
            dirs += [self.g.dir_from_polar(th, 360.0 * j / n) for j in range(n)]
        a = self.g.axis(*around)
        ref = np.cross(a, [0, 0, 1.0]) if abs(a[2]) < 0.999 else np.array([1.0, 0, 0])
        def key(w):
            dist = math.degrees(math.acos(max(-1, min(1, float(w @ a)))))
            return (round(dist / step), math.atan2(float(np.cross(ref, w) @ a), float(ref @ w)))
        dirs.sort(key=key)
        pts, near = [], tuple(around)
        if around != (0.0, 0.0):
            pts.append(tuple(self.pt.clamp(*around)))
        for w in dirs:
            near = self.g.angles_for(w, near)
            pts.append((round(near[0], 1), round(near[1], 1)))
        return list(dict.fromkeys(pts))

    # -- helpers ---------------------------------------------------------------------------
    def grab(self):
        frame, _ = self.cam.read()
        self.frames += 1
        return frame

    def show(self, frame, cands, roi=None, save_tag=None, force_save=False):
        want_save = bool(self.snap and save_tag and self.snap.due(force_save))
        if not (self.preview or want_save):
            return
        img = annotate(frame, self.det, cands, self.state, self.pt.pan, self.pt.tilt, roi)
        if want_save:
            self.snap.maybe_save(img, save_tag, force_save, raw=frame)
        if self.preview:
            cv2.imshow("tracker", img)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                self.running = False

    def status(self, msg, force=False):
        now = time.time()
        if force or now - self.last_print >= self.cfg["logging"]["print_every_s"]:
            fps = self.frames / max(1e-3, now - self.t0)
            log(f"[{self.state}] pan {self.pt.pan:+6.1f} tilt {self.pt.tilt:+6.1f}  {fps:4.1f} fps  {msg}")
            self.last_print = now

    def roi_around(self, ax, ay):
        cc = self.cfg["control"]
        x, y = self.det.deg_to_pix(ax, ay)
        hw = max(60, int(self.det.fx * math.tan(math.radians(cc["roi_deg"]))))
        x0, y0 = int(max(0, x - hw)), int(max(0, y - hw))
        x1, y1 = int(min(self.det.w, x + hw)), int(min(self.det.h, y + hw))
        if x1 - x0 < 16 or y1 - y0 < 16:
            return None
        return (x0, y0, x1, y1)

    # -- states ----------------------------------------------------------------------------
    def do_search(self, around):
        cc = self.cfg["control"]
        for (pan, tilt) in self.search_points(around):
            if not self.running:
                return None
            self.pt.move_to(pan, tilt)
            for _ in range(self.cfg["search"]["dwell_frames"]):
                frame = self.grab()
                cands = self.det.detect(frame, pointing=(pan, tilt))
                self.show(frame, cands, save_tag="search")
                self.status(f"looking... {len(cands)} candidate(s)")
                good = [c for c in cands if c["core"] <= cc["lock_max_core_dist"]]
                if not good:
                    continue
                cands = good
                # confirm: same spot in several frames
                first = cands[0]
                hits = 1
                for _ in range(cc["confirm_frames"] + 1):
                    f2 = self.grab()
                    c2 = self.det.detect(f2, pointing=(pan, tilt), prefer_deg=(first["ax"], first["ay"]))
                    c2 = [c for c in c2 if math.hypot(c["ax"] - first["ax"], c["ay"] - first["ay"])
                          <= cc["confirm_radius_deg"]]
                    c2 = [c for c in c2 if c["core"] <= cc["lock_max_core_dist"]]
                    if c2:
                        hits += 1
                        first = c2[0]
                        frame, cands = f2, c2
                    if hits >= cc["confirm_frames"]:
                        self.state = self.TRACK
                        self.show(frame, cands, save_tag="LOCK", force_save=True)
                        self.status(f"LOCKED at image offset {first['ax']:+.1f},{first['ay']:+.1f} deg "
                                    f"area {first['area']} px", force=True)
                        return first
                self.status(f"candidate not confirmed ({hits}/{cc['confirm_frames']})", force=True)
        return None

    def do_track(self, first):
        cc = self.cfg["control"]
        target = first
        predicted = (first["ax"], first["ay"])
        lost = 0
        while self.running:
            if target is not None:
                ex, ey = target["ax"], target["ay"]
                err = math.hypot(ex, ey)
                if err > cc["deadband_deg"]:
                    cur = (self.pt.pan, self.pt.tilt)
                    w = self.g.world_dir(cur[0], cur[1], ex, ey)
                    goal = self.g.angles_for(w, cur)
                    step = cc["gain"] * np.array([goal[0] - cur[0], goal[1] - cur[1]])
                    m = np.abs(step).max()
                    if m > cc["max_step_deg"]:
                        step *= cc["max_step_deg"] / m
                    new = self.pt.move_to(cur[0] + step[0], cur[1] + step[1])
                    pe = self.g.project(w, *new)
                    predicted = pe if pe is not None else (ex, ey)
                else:
                    predicted = (ex, ey)
                self.last_lock = (self.pt.pan, self.pt.tilt)

            frame = self.grab()
            pointing = (self.pt.pan, self.pt.tilt)
            roi = self.roi_around(*predicted)
            cands = self.det.detect(frame, roi=roi, pointing=pointing, prefer_deg=predicted) if roi else []
            if cands:
                target = cands[0]
                lost = 0
                self.status(f"target err {target['ax']:+5.1f},{target['ay']:+5.1f} deg  "
                            f"area {target['area']}  fill {target['fill']}")
                self.show(frame, cands, roi, save_tag="track")
            else:
                target = None
                lost += 1
                self.status(f"target missing ({lost}/{cc['lost_frames']})", force=lost == 1)
                self.show(frame, [], roi, save_tag="lost")
                if lost >= cc["lost_frames"]:
                    self.state = self.SEARCH
                    self.status("lost target - searching", force=True)
                    return

    def run(self):
        log("[tracker] centring servos (camera straight down)")
        self.pt.move_to(0, 0)
        time.sleep(0.5)
        while self.running:
            if self.state == self.SEARCH:
                found = self.do_search(self.last_lock)
                if found is None and self.running:
                    self.status("full sweep done, nothing found - repeating", force=True)
                    self.last_lock = (0.0, 0.0)
                    continue
                if found is not None:
                    self.do_track(found)

    def stop(self, *_):
        self.running = False


# --------------------------------------------------------------------------------------
# Tools: learn colour, calibrate axes, detect on images
# --------------------------------------------------------------------------------------
def learn_colour(args, cfg):
    if args.image:
        img = cv2.imread(args.image[0])
        if img is None:
            raise SystemExit(f"cannot read {args.image[0]}")
        if args.learn_at:
            cx, cy = [int(v) for v in args.learn_at.split(",")]
        else:
            if args.select:
                r = cv2.selectROI("drag a box INSIDE the red circle, then ENTER", img)
                cv2.destroyAllWindows()
                cx, cy = r[0] + r[2] // 2, r[1] + r[3] // 2
                args.learn_radius = max(3, min(r[2], r[3]) // 2)
            else:
                cx, cy = img.shape[1] // 2, img.shape[0] // 2
        gains = None
    else:
        cam = PiCamera(cfg["camera"])
        log("[learn] point the camera so the red circle fills the MIDDLE of the view")
        for s in (3, 2, 1):
            log(f"[learn] sampling in {s}...")
            time.sleep(1)
        frames, gains = [], None
        for _ in range(5):
            f, meta = cam.read()
            frames.append(f)
            gains = meta.get("ColourGains", gains)
        img = np.median(np.stack(frames), 0).astype(np.uint8)
        cam.close()
        cx, cy = img.shape[1] // 2, img.shape[0] // 2
    r = args.learn_radius
    m = np.zeros(img.shape[:2], np.uint8)
    cv2.circle(m, (cx, cy), r, 1, -1)
    px = img[m > 0]
    model = ColourModel.learn(px)
    model["max_dist"] = cfg["colour"]["max_dist"]
    # how well does it separate?
    test_cfg = deep_merge(cfg, {"colour": model})
    cm = ColourModel(test_cfg["colour"])
    hit = cm.distance_image(img) <= cm.threshold
    ring = np.zeros_like(m)
    cv2.circle(ring, (cx, cy), int(r * 2.5) + 10, 1, -1)
    inside = hit[m > 0].mean() * 100
    outside = hit[ring == 0].mean() * 100
    log(f"[learn] target pixels matched: {inside:.1f} %   background matched: {outside:.3f} %")
    if outside > 0.5:
        log("[learn] WARNING: a lot of background matches too - the colour is not very distinct. "
            "Try a smaller max_dist, locked white balance, or an IR-cut filter.")
    save_config_section(args.config, "colour", model)
    if gains:
        save_config_section(args.config, "camera", {"colour_gains": [round(float(g), 3) for g in gains]})
        log(f"[learn] white balance locked at gains {gains}")
    vis = img.copy()
    vis[hit] = (0, 255, 0)
    cv2.circle(vis, (cx, cy), r, (255, 0, 0), 2)
    out = os.path.join(os.path.expanduser(cfg["logging"]["dir"]), "learn_result.jpg")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    cv2.imwrite(out, vis)
    log(f"[learn] matched pixels shown green in {out}")


def calibrate_axes(args, cfg, cam=None, pt=None):
    cam = cam or PiCamera(cfg["camera"])
    pt = pt or PanTilt(cfg["servos"])
    det = Detector(cfg, cam.width, cam.height, cam.hfov, cam.vfov)
    d = args.cal_step
    t0 = args.cal_tilt
    size_prior = getattr(args, "cal_size_prior", False)
    last = [None]

    def measure(pan, tilt):
        pt.move_to(pan, tilt)
        time.sleep(0.4)
        pts = []
        for _ in range(4):
            f, _ = cam.read()
            c = det.detect(f, pointing=(pan, tilt), use_size_prior=size_prior, prefer_deg=last[0])
            if c:
                pts.append((c[0]["ax"], c[0]["ay"]))
        if len(pts) < 2:
            raise SystemExit(f"target not visible at pan {pan} tilt {tilt} - put the circle nearer the "
                             "middle of the view (and run --learn first)")
        m = np.median(np.array(pts), 0)
        last[0] = (float(m[0]), float(m[1]))
        return (float(m[0]), float(m[1]))

    try:
        pt.move_to(0, t0)
        if not getattr(args, "no_wait", False):
            input(f"[cal] camera is at pan 0, tilt {t0}. Place the red circle roughly in the MIDDLE "
                  "of its view (1-2 m away), then press Enter...")
        poses = [(0, t0), (d, t0), (-d, t0), (0, t0 + d), (0, t0 - d), (d, t0 + d), (-d, t0 - d)]
        obs = [measure(p, t) for p, t in poses]
        pt.move_to(0, 0)
        prm, swap, err = fit_gimbal(cfg, poses, obs)
        log(f"[cal] result: {prm}  servos swapped: {swap}  fit error {err:.2f} deg")
        if err > 2.0:
            log("[cal] WARNING: poor fit - was the circle moving, or a servo slipping? Try again, and "
                "check that tilt 0 really is straight down (servo_test.py)")
        save_config_section(args.config, "gimbal", prm)
        if swap:
            sc = cfg["servos"]
            save_config_section(args.config, "servos", {"pan": sc["tilt"], "tilt": sc["pan"]})
            log("[cal] the pan and tilt servos were the other way round - swapped them in config.json")
        log(f"[cal] done. The picture is rotated {prm['image_roll_deg']:.0f} deg"
            f"{' and mirrored' if prm['mirror'] < 0 else ''}; the tracker now accounts for that.")
    finally:
        pt.release()
        cam.close()


def detect_images(args, cfg):
    files = []
    for pattern in args.image:
        files += sorted(glob.glob(pattern)) or [pattern]
    for fn in files:
        img = cv2.imread(fn)
        if img is None:
            log(f"cannot read {fn}")
            continue
        h, w = img.shape[:2]
        hf = cfg["camera"]["hfov_deg"] or 62.2
        vf = cfg["camera"]["vfov_deg"] or 2 * math.degrees(math.atan(math.tan(math.radians(hf / 2)) * h / w))
        det = Detector(cfg, w, h, hf, vf)
        t = time.time()
        cands = det.detect(img, use_size_prior=not args.no_size_prior)
        dt = (time.time() - t) * 1000
        log(f"{fn}: {len(cands)} candidate(s) in {dt:.0f} ms")
        for c in cands[:5]:
            log(f"   at ({c['x']:.0f},{c['y']:.0f})  offset {c['ax']:+.1f},{c['ay']:+.1f} deg  "
                f"area {c['area']}  fill {c['fill']}  aspect {c['aspect']}  colour-dist {c['cdist']} core {c['core']}  "
                f"score {c['score']:.1f}")
        out = annotate(img, det, cands, "IMAGE", 0.0, 0.0, width=min(1280, w))
        base, _ = os.path.splitext(fn)
        cv2.imwrite(base + "_detect.jpg", out)
        mask = (det.colour.distance_image(img) <= det.colour.threshold).astype(np.uint8) * 255
        cv2.imwrite(base + "_mask.png", mask)


# --------------------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="Red circle tracker for Pi NoIR + pan/tilt servos")
    ap.add_argument("--config", default=DEFAULT_CONFIG_PATH)
    ap.add_argument("--preview", action="store_true", help="show a live window")
    ap.add_argument("--no-snapshots", action="store_true", help="don't save debug JPEGs")
    ap.add_argument("--no-servos", action="store_true", help="run without moving servos")
    ap.add_argument("--learn", action="store_true", help="learn target colour")
    ap.add_argument("--learn-radius", type=int, default=25, help="sample radius in pixels")
    ap.add_argument("--learn-at", help="x,y pixel of the target centre (with --image)")
    ap.add_argument("--select", action="store_true", help="drag a box on --image to learn from")
    ap.add_argument("--calibrate-axes", action="store_true")
    ap.add_argument("--cal-step", type=float, default=10.0)
    ap.add_argument("--cal-tilt", type=float, default=25.0, help="tilt used during calibration")
    ap.add_argument("--image", nargs="+", help="run detection on image file(s) instead of the camera")
    ap.add_argument("--no-size-prior", action="store_true", help="(with --image) ignore expected size")
    args = ap.parse_args()
    cfg = load_config(args.config)
    if args.no_servos:
        cfg["servos"]["backend"] = "dummy"

    if args.learn:
        return learn_colour(args, cfg)
    if args.image:
        return detect_images(args, cfg)
    if args.calibrate_axes:
        return calibrate_axes(args, cfg)

    cam = PiCamera(cfg["camera"])
    pt = PanTilt(cfg["servos"])
    tr = Tracker(cfg, cam, pt, preview=args.preview, snapshots=not args.no_snapshots)
    signal.signal(signal.SIGTERM, tr.stop)
    signal.signal(signal.SIGINT, tr.stop)
    try:
        tr.run()
    finally:
        log("[tracker] stopping - centring servos")
        try:
            pt.move_to(0, 0)
            time.sleep(0.3)
        except Exception:
            pass
        pt.release()
        cam.close()


if __name__ == "__main__":
    main()
