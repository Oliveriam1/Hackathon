# Red circle tracker: Pi 3A + NoIR camera + MG996R pan/tilt

The camera searches the ground below the drone for the red circle. Once it finds it, it locks on and keeps the circle in the middle of the picture while the drone moves.

| File | What it does |
|---|---|
| `tracker.py` | Main program: search, lock on, track. Also has the learn, calibrate and test-image tools |
| `config.json` | All the settings. Edit this file, not the code |
| `servo_test.py` | Moves the servos by hand so you can find the centre position and the limits |
| `simulate.py` | Runs the real tracker code on a PC against a simulated drone view. No Pi needed |
| `install.sh` | One-time install on the Pi |
| `redtrack.service` | Optional: starts the tracker automatically at boot |

---

## 1. Wiring

```
Pi physical pin 38 (GPIO20) ──── PAN servo signal  (orange/yellow wire)
Pi physical pin 40 (GPIO21) ──── TILT servo signal (orange/yellow wire)
Pi GND (e.g. pin 39) ─────────── servo power GND   ← grounds MUST be joined
5–6 V BEC / UBEC, 3 A or more ── servo red wires   ← NOT from the Pi's 5 V pin
```

- **Never power the MG996Rs from the Pi.** Each one can pull about 2.5 A when it stalls, and that will brown out and reboot the Pi mid-flight. Use a separate 5–6 V UBEC, rated 3 A or more, running off the drone battery.
- A 3.3 V signal drives MG996Rs fine in practice. If a servo twitches or ignores commands, add a 74AHCT125 level shifter.
- Pins 38 and 40 have no hardware PWM, so the program uses **pigpio**, which produces clean, jitter-free servo pulses on any pin.

## 2. Install (Raspberry Pi OS Bookworm)

```bash
# copy this folder to the Pi as ~/redtrack, then:
cd ~/redtrack
bash install.sh
rpicam-hello -t 3000        # camera check
```

## 3. Setup, in this order

### a) Servo centre and limits
```bash
python3 servo_test.py
```
The program expects this kind of mount: the **pan** servo turns the whole head left and right around the vertical axis, and the **tilt** servo swings the camera away from straight down. **Tilt 0 must be exactly straight down**, because everything is measured from there.
- Type `c`. Both servos go to 1500 µs. Use `us tilt 1560` style commands to find the tilt pulse where the camera points **straight down**, and put it in `config.json → servos → tilt → center_us`. For pan, any middle position is fine.
- Type `t 45`, then `t -45`, and check the camera really swings about ±45°. If not, adjust `us_per_deg` (about 11.1 for a 180° MG996R). Do the same with `p`.
- Pan should reach about ±90°. Together with tilt going both ways, that covers every direction, so the camera never needs a 180° pan swing.
- Set `min_deg` and `max_deg` so the camera can't hit the drone's legs or pull its cables tight.

### b) Teach it the colour of your circle (outdoors, real light)
A NoIR camera has no infrared filter. Sunlight adds infrared to every colour, so red looks pink and faded, as it does in your photo. The tracker has to learn how *your* circle looks through *your* camera.

Put the circle on the ground in sunlight. Hold the drone/camera 2–3 m above it so the circle fills the **middle** of the view, then run:
```bash
python3 tracker.py --learn
```
It saves the colour model to `config.json` and **locks the white balance** so the colours stay the same in flight. It also prints how much of the circle matched and how much of the background matched. Aim for more than 90 % of the circle and less than 0.2 % of the background. It saves `~/tracker_logs/learn_result.jpg`, with every pixel it counts as "target" painted green.

You can also learn from a photo on a PC: `python3 tracker.py --learn --image photo.jpg --select` (drag a box inside the circle).

### c) Calibrate the servo directions
This step measures how the picture sits on the mount: its rotation (your photo is rotated 90°), each servo's direction, and whether the servos are plugged in the other way round. Run:
```bash
python3 tracker.py --calibrate-axes
```
It tilts the camera to 25° and waits. Hold or place the printed circle in the middle of the view (about 1–2 m away), keep it still, and press Enter. It then moves through 7 positions, watches where the circle appears in each, and fits the mount geometry. A fit error under 1° is good. The results go into `config.json → gimbal`, and it swaps the pan/tilt pins in the config itself if they were reversed. You don't need to rewire anything or flip signs by hand.

### d) Bench test
```bash
python3 tracker.py --preview      # with a monitor or VNC
python3 tracker.py                # headless; watch the text output
```
Move the printed circle around. The camera should follow it. **To stop:** press Ctrl+C. The servos return to straight down.

## 4. Flying

Run `python3 tracker.py` (or install the service; change `User=pi` and the paths in `redtrack.service` if your username isn't `pi`). The tracker:

1. Centres the camera (straight down).
2. **SEARCH**: looks straight down first, then in rings further and further out (up to 80° from vertical), all the way around.
3. When it sees a candidate, it has to see it again in 3 frames at the same spot, with a clean enough colour, before it **LOCKS**.
4. **TRACK**: from the circle's position in the picture and the current servo angles, it works out the exact 3D direction to the circle. It solves which pan and tilt point straight at it and moves 70 % of the way each frame. This also works when the circle is almost directly below, where pan only spins the picture. There it holds pan still and only tilts. It only looks in a small window around where the circle should be, which is fast and ignores look-alikes elsewhere.
5. If it misses the circle for 8 frames, it searches again, starting where it last saw it.

Every 5 s it saves an annotated JPEG to `~/tracker_logs`, plus one each time it locks. The top-right corner shows a zoomed view of what it's tracking, so after a flight you can see what it saw. Set `"save_raw": true` under `logging` to also save the full-size frames. You can then re-test and re-tune on a PC with:
```bash
python3 tracker.py --image ~/tracker_logs/*_raw.png
```

## 5. Limits you should know about

**The circle is small for this height.** At 20 m altitude a 20 cm circle looks like this (Camera v2, width of the picture):

| Circle's ground distance from under the drone | 1640 px mode (default, ~2–4 fps on Pi 3A) | 3280 px full-res mode (~1 fps) |
|---|---|---|
| 0 m (straight below) | 14 × 14 px | 27 × 27 px |
| 20 m | 10 × 7 px | 19 × 14 px |
| 40 m | 6 × 3 px (marginal) | 12 × 5 px |
| 60 m | 4 × 1 px (**not detectable**) | 9 × 3 px (marginal) |

In the simulator it reliably found and held the circle out to about 30–35 m sideways. Beyond that the circle is only a few pixels and it blends into the background. Ways to get the full 60 m, best first:
- **A bigger target.** A 50 cm circle gives 6× the pixels; 1 m gives 25×.
- **A higher-resolution mode.** Set `"resolution": [3280, 2464]` under `camera`. It's slower, and it's tight on the 3A's 512 MB of memory.
- **A narrower lens** (for example the HQ camera with a 6–16 mm lens), with `hfov_deg`/`vfov_deg` set in the config.

**NoIR colours.** Grass, leaves and many camouflage nets reflect a lot of infrared, so through a NoIR camera they can look pink, which is close to your circle's colour. The tracker defends against this by rejecting blobs that are the wrong size for the height, not round, not a clean enough colour, or part of a larger pink area. But **the single best improvement is a normal camera (with an IR filter), or an IR-cut filter over the NoIR lens**. Then red is really red and the camo is green.

**Other things to check:**
- Set `target → altitude_m` to your real flying height. It sets the expected circle size. If you fly at varying heights, loosen `size_min_factor`/`size_max_factor`.
- Vibration blurs small targets. Soft-mount the camera, and consider `"exposure_us": 1000` in bright sun.
- The angle maths assumes the drone is roughly level. When it tilts, the servos simply chase the error; it doesn't use the flight controller's attitude.

## 6. Test on a PC without the Pi
```bash
pip install opencv-python numpy
python3 simulate.py --target 20 -25            # circle 20 m east, 25 m south
python3 simulate.py --target 5 3 --roll 90     # camera mounted rotated 90°
python3 tracker.py --image yourphoto.jpg --no-size-prior
```

## 7. Tuning cheat-sheet (`config.json`)

| Problem | Try |
|---|---|
| Circle not found at all | Redo `--learn` outdoors; raise `colour.max_dist` (3 → 4) |
| Locks onto wrong things | Lower `colour.max_dist`; lower `control.lock_max_core_dist`; set `altitude_m` correctly |
| Camera oscillates around the circle | Lower `control.gain` (0.7 → 0.5); raise `servos.settle_s` |
| Tracking too slow or laggy | Raise `gain` (max ~0.9); lower `resolution` |
| Loses circle when drone moves fast | Raise `control.roi_deg` (5 → 8) |
| Servos jitter | Make sure `pigpiod` is running (`sudo systemctl status pigpiod`) |
